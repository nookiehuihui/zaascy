CREATE VIEW dbo.stu_for_oa
AS
SELECT     dbo.XTYH.reny_lx AS person_type, dbo.XTYH.DENGLM AS username, dbo.XTYH.MIM AS password, dbo.RYK_YDYJS.xingm AS name, 
                      dbo.RYK_YDYJS.zhaop AS picture, dbo.RYK_YDYJS.xingb AS gender, dbo.RYK_YDYJS.shenfenz AS id_card, dbo.RYK_YDYJS.danw_id AS dept_id, 
                      dbo.RYK_YDYJS.shouj AS cellphone, dbo.RYK_YDYJS.email, dbo.RYK_YDYJS.shifouyx AS stat, dbo.XTYH.youxiaoq AS end_time
FROM         dbo.RYK_YDYJS INNER JOIN
                      dbo.XTYH ON dbo.RYK_YDYJS.yanjius_id = dbo.XTYH.yanjius_id
WHERE     (dbo.RYK_YDYJS.shifouyx = 1) AND (dbo.RYK_YDYJS.shifouly = 1)
