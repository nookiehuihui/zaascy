CREATE VIEW dbo.temp_for_oa
AS
SELECT     dbo.XTYH.reny_lx AS person_type, dbo.RYK_LSRY.xingm AS name, dbo.RYK_LSRY.zhaop AS picture, dbo.RYK_LSRY.xingb AS gender, 
                      dbo.RYK_LSRY.renyuanlx AS person_type_more, dbo.RYK_LSRY.shenfenz AS id_card, dbo.RYK_LSRY.danw_id AS dept_id, dbo.RYK_LSRY.shouj AS cellphone, 
                      dbo.RYK_LSRY.email, dbo.RYK_LSRY.shifouyx AS stat, dbo.XTYH.DENGLM AS username, dbo.XTYH.MIM AS password, dbo.XTYH.youxiaoq AS end_time
FROM         dbo.RYK_LSRY INNER JOIN
                      dbo.XTYH ON dbo.RYK_LSRY.linshiry_id = dbo.XTYH.linshiry_id
WHERE     (dbo.RYK_LSRY.shifouyx = 1) AND (dbo.RYK_LSRY.shifouly = 1)
