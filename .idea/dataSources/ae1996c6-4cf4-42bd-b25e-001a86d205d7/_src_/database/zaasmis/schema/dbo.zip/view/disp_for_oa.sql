CREATE VIEW dbo.disp_for_oa
AS
SELECT     dbo.XTYH.reny_lx AS person_type, dbo.RYK_LWPQRY.xingm AS name, dbo.RYK_LWPQRY.zhaop AS picture, dbo.RYK_LWPQRY.xingb AS gender, 
                      dbo.RYK_LWPQRY.shenfenz AS id_card, dbo.RYK_LWPQRY.danw_id AS dept_id, dbo.RYK_LWPQRY.shouj AS cellphone, dbo.RYK_LWPQRY.email, 
                      dbo.RYK_LWPQRY.shifouyx AS stat, dbo.XTYH.DENGLM AS username, dbo.XTYH.MIM AS password, dbo.XTYH.youxiaoq AS end_time
FROM         dbo.RYK_LWPQRY INNER JOIN
                      dbo.XTYH ON dbo.RYK_LWPQRY.laowupqry_id = dbo.XTYH.laowupqry_id
WHERE     (dbo.RYK_LWPQRY.shifouyx = 1) AND (dbo.RYK_LWPQRY.shifouly = 1)
