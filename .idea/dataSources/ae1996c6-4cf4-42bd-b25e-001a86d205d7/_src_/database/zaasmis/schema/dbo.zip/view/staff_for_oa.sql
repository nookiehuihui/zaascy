CREATE VIEW dbo.staff_for_OA
AS
SELECT     dbo.XTYH.DENGLM AS username, dbo.XTYH.MIM AS password, dbo.XTYH.reny_lx AS person_type, dbo.RYK_RYJBXX.XINGM AS name, 
                      dbo.XTYH.youxiaoq AS end_time, dbo.RYK_RYJBXX.DANW_ID AS dept_id, dbo.RYK_RYJBXX.XINGB AS gender, dbo.RYK_RYJBXX.SHENFZ AS id_card, 
                      dbo.RYK_RYJBXX.ZHAOPWJM AS picture, dbo.RYK_RYJBXX.ZHUANGT AS stat, dbo.RYK_RYJBXX.EMAIL, dbo.RYK_RYJBXX.SHOUJ AS cellphone
FROM         dbo.XTYH INNER JOIN
                      dbo.RYK_RYJBXX ON dbo.XTYH.RENY_ID = dbo.RYK_RYJBXX.RENY_ID AND dbo.XTYH.RENY_ID = dbo.RYK_RYJBXX.RENY_ID AND 
                      dbo.XTYH.RENY_ID = dbo.RYK_RYJBXX.RENY_ID
WHERE     (dbo.RYK_RYJBXX.ZHUANGT = 'Staff')
