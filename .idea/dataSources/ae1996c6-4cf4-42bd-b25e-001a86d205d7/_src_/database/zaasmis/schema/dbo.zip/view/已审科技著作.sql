/*
2005-2009年  科研年报/科技著作的已审记录，按前台字段；
年份 单位 序号 书名 主编单位 出版社 出版社级别 出版时间 字数(万) 业绩分 
NIAND,DANW_ID,XUH,MINGC,ZHUBDW,CHUBS,CHUBSJB,CHUBSJ,ZIS,YEJF
*/
create view 已审科技著作 as
select NIAND,DANW_ID,XUH,MINGC,ZHUBDW,CHUBS,CHUBSJB,CHUBSJ,ZIS,YEJF
from KY_NB_KJZZ
where NIAND in (2005,2006,2007,2008,2009) and SHENGHZT='Y'
