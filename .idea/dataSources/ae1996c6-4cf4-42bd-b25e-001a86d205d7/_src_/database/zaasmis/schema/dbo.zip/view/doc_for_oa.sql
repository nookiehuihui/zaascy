CREATE VIEW dbo.doc_for_oa
AS
SELECT     dbo.XTYH.DENGLM AS username, dbo.XTYH.MIM AS password, dbo.XTYH.reny_lx AS person_type, dbo.RYK_BSH.xingm AS name, dbo.XTYH.youxiaoq AS end_time, 
                      dbo.RYK_BSH.danw_id AS dept_id, dbo.RYK_BSH.xingb AS gender, dbo.RYK_BSH.shenfenz AS id_card, dbo.RYK_BSH.zhaop AS picture, 
                      dbo.RYK_BSH.shifouyx AS stat, dbo.RYK_BSH.email, dbo.RYK_BSH.shouj AS cellphone
FROM         dbo.XTYH INNER JOIN
                      dbo.RYK_BSH ON dbo.XTYH.boshih_id = dbo.RYK_BSH.boshih_id
WHERE     (dbo.RYK_BSH.shifouyx = 1) AND (dbo.RYK_BSH.shifouly = 1)
