/*
2005-2009年  科研年报/学术论文的已审记录，按前台字段，按单位分成不同的sheet；
年份 单位 序号 论文标题 期刊名称 卷(期) 页码范围 论文级别 作者 论文业绩分 获奖年份 获奖等级 
 NIAND,dwmc,XUH,LUNWBT,QIKMC,JUAN,YEMFW,LUNWJB,LUNWZZ,LUNWYJF,HUOJNF,HUOJDJ


*/
CREATE VIEW dbo.已审学术论文
AS
SELECT NIAND, dwmc, XUH, LUNWBT, QIKMC, JUAN, YEMFW, LUNWJB, LUNWZZ, 
      LUNWYJF, HUOJNF, HUOJDJ
FROM dbo.KY_NB_XSLW
WHERE (NIAND IN (2005, 2006, 2007, 2008, 2009)) AND (SHENGHZT = 'Y')
